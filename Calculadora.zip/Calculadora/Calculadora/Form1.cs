﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Calculadora
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnSoma_Click(object sender, EventArgs e)
        {
            float varDigito1 = float.Parse(txtDigito1.Text);
            float varDigito2 = float.Parse(txtDigito2.Text);
            float soma;

            soma = varDigito1 + varDigito2;
            MessageBox.Show("Soma:" + soma);
        }

        private void btnSubtracao_Click(object sender, EventArgs e)
        {
            float varDigito1 = float.Parse(txtDigito1.Text);
            float varDigito2 = float.Parse(txtDigito2.Text);
            float subtracao;

            subtracao = varDigito1 - varDigito2;
            MessageBox.Show("Subtração:" + subtracao);
        }

        private void btnMultiplicacao_Click(object sender, EventArgs e)
        {
            float varDigito1 = float.Parse(txtDigito1.Text);
            float varDigito2 = float.Parse(txtDigito2.Text);
            float multiplicacao;

            multiplicacao = varDigito1 * varDigito2;
            MessageBox.Show("Multiplicação:" + multiplicacao);
        }

        private void btnDivisao_Click(object sender, EventArgs e)
        {
            float varDigito1 = float.Parse(txtDigito1.Text);
            float varDigito2 = float.Parse(txtDigito2.Text);
            float divisao;

            divisao = varDigito1 / varDigito2;
            MessageBox.Show("Divisão:" + divisao);
        }
    }
}
