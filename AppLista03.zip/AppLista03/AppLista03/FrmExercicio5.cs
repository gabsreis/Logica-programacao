﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppLista03
{
    public partial class FrmExercicio5 : Form
    {
        public FrmExercicio5()
        {
            InitializeComponent();
        }

        private void lblPreço_Click(object sender, EventArgs e)
        {

        }

        private void btnArea_Click(object sender, EventArgs e)
        {
            float Base = float.Parse(txtBase.Text);
            float Altura = float.Parse(txtAltura.Text);
            float Area = Base * Altura;

            lblArea.Text = "A área é " + Area;
        }

        private void btnPerímetro_Click(object sender, EventArgs e)
        {
            float Base = float.Parse(txtBase.Text);
            float Altura = float.Parse(txtAltura.Text);
            float Perimetro = Base + Altura;

            lblPerimetro.Text = "O perímetro é " + Perimetro;
        }
    }
}
