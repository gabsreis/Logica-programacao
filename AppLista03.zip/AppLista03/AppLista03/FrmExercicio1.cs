﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppLista03
{
    public partial class FrmExercicio01 : Form
    {
        public FrmExercicio01()
        {
            InitializeComponent();
        }

        private void btnSoma_Click(object sender, EventArgs e)
        {
            float Num1 = float.Parse(txtNum1.Text);
            float Num3 = float.Parse(txtNum3.Text);
            float Soma;
            Soma = Num1 + Num3;

            lblSoma.Text = "Soma igual a " + Soma;

        }

        private void btnMedia_Click(object sender, EventArgs e)
        {
            float Num1 = float.Parse(txtNum1.Text);
            float Num2 = float.Parse(txtNum2.Text);
            float Num3 = float.Parse(txtNum3.Text);
            float Media;
            Media = (Num1 + Num2 + Num3) / 3;

            lblMedia.Text = "Média igual a " + Media;
        }

        private void btnPorcentagem_Click(object sender, EventArgs e)
        {
            float Num1 = float.Parse(txtNum1.Text);
            float Num2 = float.Parse(txtNum2.Text);
            float Num3 = float.Parse(txtNum3.Text);
            float total, porcNum1, porcNum2, porcNum3;

            total = Num1 + Num2 + Num3;
            porcNum1 = Num1 / total;
            porcNum2 = Num2 / total;
            porcNum3 = Num3 / total;

            lblPorcentagem.Text = "Num1 " + porcNum1*100 + "% - " + "Num2 " + porcNum2*100 + "% - " + "Num3 " + porcNum3*100 + "%";
        }
    }
}
