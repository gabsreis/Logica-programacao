﻿namespace App2B216GabrielReis
{
    partial class FrmExerc4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblPi = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lblPi
            // 
            this.lblPi.AutoSize = true;
            this.lblPi.Location = new System.Drawing.Point(283, 144);
            this.lblPi.Name = "lblPi";
            this.lblPi.Size = new System.Drawing.Size(10, 13);
            this.lblPi.TabIndex = 0;
            this.lblPi.Text = " ";
            // 
            // FrmExerc4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lblPi);
            this.Name = "FrmExerc4";
            this.Text = "Exercício 4";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblPi;
    }
}